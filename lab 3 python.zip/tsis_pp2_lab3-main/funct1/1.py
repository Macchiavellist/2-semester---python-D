def grams(gram):
    ounces = 0.03527396 * gram
    return ounces
gram=float(input("gram:"))
print("ounces=",grams(gram))