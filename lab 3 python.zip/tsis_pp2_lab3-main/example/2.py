def rreverse_string(s):
    reverse_soz=s[::-1]
    return reverse_soz
    
k=str(str(input("soz:")))
print(rreverse_string(k))