def evennuber(n):
    if n%2==0:
        return True
    return False
k=int(input("n:"))
print(evennuber(k))